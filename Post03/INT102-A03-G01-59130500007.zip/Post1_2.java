class Post1_2{
	public static void main(String[] args){
		String test1 = "Test";
		String test2 = "Test";
		System.out.println(test1.equalsInCase(test2));
		}
}