class Post1_3{
	public static void main(String[] args){
		String test1 = "Test";
		String test2 = "TEST";
		System.out.println(test1.equalsIgnoreCase(test2));
		}
}