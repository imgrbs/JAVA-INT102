class Post1{
	public static void main(String[] args){
		String test1 = "Test";
		String test2 = "Test";
		System.out.print(test1==test2);
		}
}